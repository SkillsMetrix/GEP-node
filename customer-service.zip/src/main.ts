import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import axios from 'axios';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  await app.listen(process.env.PORT ?? 3001);

  // register to registry

  await axios.post('http://localhost:4000/registry/register',{
    name: 'customer',
    host: 'localhost',
    port: 3001
  })
}
bootstrap();
