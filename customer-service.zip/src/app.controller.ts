import { Controller, Get, Inject } from '@nestjs/common';
import { AppService } from './app.service';
import { HttpService } from '@nestjs/axios'
import { firstValueFrom } from 'rxjs'
import axios from 'axios';
import { ClientProxy, ClientProxyFactory, Transport } from '@nestjs/microservices';
@Controller('customer')
export class AppController {
  constructor() { }
  private gatewayURL = 'http://localhost:3000/gateway'
  @Get('buy')
  async buy() {
    const response = await axios.get(`${this.gatewayURL}/shop/bill`, {
      params: { item: 'Book', amount: 300 }
    })
    return { message: 'Customer Purched Items ', bill: response.data }

  }
}

/*  // discover
 const { data: shop } = await axios.get('http://localhost:4000/services/shop-service')
 if (!shop) {
   return { error: 'Serice not found in registry' }
 }

 const shopClient = ClientProxyFactory.create({
   transport: Transport.TCP,
   options: { host: shop.host, port: shop.port }
 })
 const bill = await firstValueFrom(
   shopClient.send({ cmd: 'create_bill' }, { customer, items })
 )
 return {
   customer, items, bill
 }
} */

