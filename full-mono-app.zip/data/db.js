
const Product= require('../models/Product')
module.exports ={
    users:[
       { id:1,name:"admin",email:"admin@mail.com"},
        { id:2,name:"manager",email:"manager@mail.com"}
    ],

products:[
    new Product(1,"laptop",1000),
    new Product(2,"mouse",200)
],
customers:[
    {id:1,name:'sam',address:'mumbai'},
    {id:2,name:'diana',address:'NY'}

]

}