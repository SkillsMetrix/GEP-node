
const express= require('express')
const productRoutes=require('./routes/product.routes')
const { notFound, errorHandler } = require('./middleware/errorHandler')
const app= express()
const morgan= require('morgan')
app.use(express.json())
app.use(notFound)
app.use(errorHandler)

app.use(morgan('dev'))


app.use('/products',productRoutes)

app.listen(3000,()=>{
    console.log('server is ready...!');
    
})