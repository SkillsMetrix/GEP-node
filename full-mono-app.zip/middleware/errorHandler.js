// Global Error Handler
const errorHandler=(err,req,res,next)=>{
    console.error(`[ERROR] ${err.message}`)
    res.status(err.statusCode || 500).json({
        status:'error',
        message:err.message || 'Internal Server Error'
    })
}
// for 404
const notFound=(err,req,res,next)=>{
    console.error(`[ERROR] ${err.message}`)
    const error= new Error(`Route Not Found : ${req.originalUrl}`)
   error.statusCode=404;
   next(error)
    
}
module.exports={errorHandler,notFound}