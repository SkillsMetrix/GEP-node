
const ps= require('../services/product.service')

const asyncHandler= require('../middleware/asyncHandler')

exports.getProducts=asyncHandler(async(req,res)=>{
    res.json(ps.getAllProducts())
})


exports.addProduct=asyncHandler(async(req,res)=>{
    const product=ps.createProducts(req.body)
    res.status(201).json(product)
})