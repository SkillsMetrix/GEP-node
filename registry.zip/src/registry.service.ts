import { Injectable } from "@nestjs/common";


@Injectable()
export class RegistryService{

    private service:Record<string,{host:string,port:number}>={}

    register(name:string,host:string,port:number){
        this.service[name]={host,port}
         return {message: `${name} registered ate ${host}:${port}`}
    }

    getService(name:string){
        return this.service[name]
    }
    getAll(){
        return this.service;
    }
}