import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { RegistryService } from './registry.service';


@Controller('registry')
export class AppController {
  constructor(private regiser: RegistryService) { }

  @Get(':name')
  getService(@Param('name') name: string) {
    return this.regiser.getService(name)
  }
  @Post('register')
  register(@Body() body: { name: string, host: string, port: number }) {
    return this.regiser.register(body.name, body.host, body.port)
  }
  @Get()
  getAll() {
    return this.regiser.getAll()
  }
}
