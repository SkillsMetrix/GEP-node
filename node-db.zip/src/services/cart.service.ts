
import CartItemModel, {CartItemDocument} from '../models/cart.model'

class CartService{
   /*  private cart: Cart={items:[]}
    private nextId=1

    getAllItems(): CartItem[]{
        return this.cart.items
    }
    getItemById(id:number):CartItem | undefined{
        return this.cart.items.find(item => item.id === id)
    }
    deleteItemById(id:number):boolean{
        const index= this.cart.items.findIndex(item => item.id === id)
        if( index === -1) return false
        this.cart.items.splice(index,1)
        return true


    } */
   async addItem(name:string,price:number,quantity:number):Promise<CartItemDocument>{
        const newItem= new CartItemModel({name,price,quantity})
        return await newItem.save()
}
}
export default new CartService()