
import mongoose from 'mongoose'

const connectDB= async() => {
    try {
        await mongoose.connect('mongodb+srv://admin:admin123@cluster0.rle5i.mongodb.net/gkedb?retryWrites=true&w=majority&appName=Cluster0')
    } catch(error){console.log('unable to connect');
    }
}
export default connectDB