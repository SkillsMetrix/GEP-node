import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { RegistryService } from './registry.service';


@Controller('registry')
export class AppController {
constructor(private registry: RegistryService) {}

  @Post('register')
  register(@Body() body: { name: string; host: string; port: number }) {
    return this.registry.register(body.name, body.host, body.port);
  }

  @Get(':name')
  getService(@Param('name') name: string) {
    return this.registry.getService(name);
  }

  @Get()
  getAll() {
    return this.registry.getAll();
  }
}
