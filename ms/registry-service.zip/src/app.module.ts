import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { RegistryService } from './registry.service';
 
@Module({
  imports: [],
  providers:[RegistryService],
  controllers: [AppController],
  
})
export class AppModule {}
