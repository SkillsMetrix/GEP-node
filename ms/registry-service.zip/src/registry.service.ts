import { Injectable } from "@nestjs/common";


@Injectable()
export class RegistryService{

     private services: Record<string, { host: string; port: number }> = {};

  register(name: string, host: string, port: number) {
    this.services[name] = { host, port };
    return { message: `${name} registered at ${host}:${port}` };
  }

  getService(name: string) {
    return this.services[name];
  }

  getAll() {
    return this.services;
  }
}