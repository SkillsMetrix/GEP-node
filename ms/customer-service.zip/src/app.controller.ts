import { Controller, Get } from '@nestjs/common';
import axios from 'axios';

@Controller('customer')
export class CustomerController {
  private gatewayUrl = 'http://localhost:3000/gateway';

  @Get('buy')
  async buy() {
    // Call Shop via Gateway
    const response = await axios.get(`${this.gatewayUrl}/shop/bill`, {
      params: { item: 'Book', amount: 200 },
    });

    return { message: 'Customer purchased item', bill: response.data };
  }
}
