import { Module } from '@nestjs/common';
import { CustomerController } from './app.controller';
import { AppService } from './app.service';
import { HttpModule } from '@nestjs/axios';
import { ClientsModule, Transport } from '@nestjs/microservices';

@Module({
  imports: [
  
  ],
  controllers: [CustomerController],
  
})
export class AppModule {}
