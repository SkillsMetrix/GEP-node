import { Controller, All, Param, Req } from '@nestjs/common';
import { Request } from 'express';
import axios from 'axios';

@Controller('gateway')
export class AppController {
  private registryUrl = 'http://localhost:4000/registry';

  @All(':service/*path')
  async forward(
    @Param('service') service: string,
    @Param('path') path: string,   // ✅ will contain "buy" when URL = /gateway/customer/buy
    @Req() req: Request,
  ) {
    try {
      const { data: svc } = await axios.get(`${this.registryUrl}/${service}`);
      if (!svc) {
        return { error: `Service ${service} not found` };
      }

      // ⚡ Build target URL
      const targetUrl = `http://${svc.host}:${svc.port}/${service}/${path || ''}`;

      console.log(`➡️ Forwarding ${req.method} ${req.originalUrl} → ${targetUrl}`);

      const response = await axios({
        method: req.method as any,
        url: targetUrl,
        data: req.body,
        params: { ...req.query },
      });

      return response.data;
    } catch (err: any) {
      console.error('❌ Gateway error:', err.message);
      return { error: 'Gateway error', details: err.message };
    }
  }
}
