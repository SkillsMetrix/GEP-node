import { Injectable, OnModuleInit } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import axios  from 'axios';
@Injectable()
export class AppService {

  
  createBill(data: { customer: string, items: string[] }) {
    const total = data.items.length * 100
    return {
      message: `Bill created for ${data.customer}`, total, items: data.items
    };
  }
}
