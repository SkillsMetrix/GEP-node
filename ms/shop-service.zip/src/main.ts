import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

import axios from 'axios';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
   const port= 3002;
  await app.listen(port);

  await axios.post('http://localhost:4000/registry/register',{
    name: 'shop',
    host: 'localhost',
    port: 3002
  })

}
bootstrap();
