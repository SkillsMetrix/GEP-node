import { Body, Controller, Get, Post, Query } from '@nestjs/common';
import { AppService } from './app.service';
import { MessagePattern } from '@nestjs/microservices';

@Controller('shop')
export class AppController {
  constructor() { }

  @Get('bill')
  createBill(@Query('item') item:string, @Query('amount') amount:number) {

    return {shop: 'Shop Service',item,amount, status:'Billed'}

  }
}
