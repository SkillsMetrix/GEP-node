
import {Cart,CartItem} from '../models/cart.model'

class CartService{
    private cart: Cart={items:[]}
    private nextId=1

    getAllItems(): CartItem[]{
        return this.cart.items
    }
    getItemById(id:number):CartItem | undefined{
        return this.cart.items.find(item => item.id === id)
    }
    deleteItemById(id:number):boolean{
        const index= this.cart.items.findIndex(item => item.id === id)
        if( index === -1) return false
        this.cart.items.splice(index,1)
        return true


    }
    addItem(name:string,price:number,quantity:number):CartItem{
        const newItem:CartItem={
            id: this.nextId++,
            name,
            price,
            quantity
        }
        this.cart.items.push(newItem)
        return newItem
    }
}
export default new CartService()