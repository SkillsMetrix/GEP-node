
import {request,response} from 'express'
import cartService from '../services/cart.service'


class CartController{
    getAllItems(req:Request,res:Response){
        res.json(cartService.getAllItems())
    }
    getItem(req:Request,res:Response){
        const id=Number(req.params.id)
        const item= cartService.getItemById(id)
        if(!item) return res.status(404).json({"message":"id not found"})
        res.json(item)
    }
    deleteItem(req:Request,res:Response){
        const id=Number(req.params.id)
        const success= cartService.deleteItemById(id)
        if(!success) return res.status(404).json({"message":"id not found"})
        res.status(204).send()
    }
    addItem(req:Request,res:Response){
        const {name,price,quantity} = req.body
        if(!name || price == null || quantity==null){
            return res.status(400).json({"message":"Invalid Data"})
        }
        const newItem= cartService.addItem(name,price,quantity)
        res.status(201).json(newItem)
    }
}
export default new CartController()