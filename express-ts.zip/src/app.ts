import express from 'express'

import bodyParser from 'body-parser'
import cartRoutes from './routes/cart.routes'

const app=express()
app.use(bodyParser.json())

app.use('/api/cart',cartRoutes)

app.listen(4000,()=>{
    console.log('server is ready');
    
})