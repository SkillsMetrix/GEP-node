import mongoose, { Document, Schema } from "mongoose";

export interface CartItemDocument extends Document {
  name: string;
  price: number;
  quantity: number;
}

const CartItemSchema = new Schema<CartItemDocument>({
  name: { type: String, required: true },
  price: { type: Number, required: true },
  quantity: { type: Number, required: true },
},
  {timestamps:true}
);
const CartItemModel=mongoose.model<CartItemDocument>("CartSchema",CartItemSchema)
export default CartItemModel