
import {Router} from 'express'
import cartController from '../controllers/cart.controller'


const router= Router()

/* 

router.get('/:id',cartController.getAllItems)
router.delete('/:id',cartController.deleteItem) */
router.get('/',cartController.getAllItems);
router.post('/',cartController.addItem);

export default router