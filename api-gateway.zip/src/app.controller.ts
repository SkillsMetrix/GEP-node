import { Controller, All, Param, Req } from '@nestjs/common';
import { Request } from 'express';
import axios from 'axios';

@Controller('gateway')
export class AppController {
  private registryUrl = 'http://localhost:4000/registry';

  @All(':service/:path')
  async forward(
    @Param('service') service: string,
    @Param('path') path: string,
    @Req() req: Request,

  ) {
    try {
      // 🔍 Lookup service in registry
      const { data: svc } = await axios.get(`${this.registryUrl}/${service}`);
      if (!svc) {
        return { error: `Service ${service} not found` };
      }

     
      //const durl = `http://${svc.host}:${svc.port}/${service}/${path || ''}`;
      const url= `http://${svc.host}:${svc.port}/${service}/${path} || ''}`
 
      const response = await axios({
        method: req.method as any,
        url,
        data: req.body,
        params: { ...req.query },  
      });

      return response.data;
    } catch (err: any) {
      return { error: 'Gateway error', details: err.message };
    }
  }
}